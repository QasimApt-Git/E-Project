/* ============================================
   COSY AIRCONDITIONERS — contact-form.js
   ============================================
   This file validates the contact form before submission.
   
   HOW IT WORKS (Student 5 will implement):
   1. Listen for "submit" event on the contact form
   2. Prevent default submission (so page doesn't reload)
   3. Check if name is at least 2 characters
   4. Check if email matches a regex pattern
   5. Check if phone is 10 digits (optional but good)
   6. Check if message is not empty
   7. If all valid: show success alert
   8. If invalid: show specific error messages
   
   VANILLA JS ONLY — no jQuery or frameworks.
   ============================================ */

// Placeholder — Student 5 implements this.
console.log("contact-form.js loaded — ready for Student 5");
