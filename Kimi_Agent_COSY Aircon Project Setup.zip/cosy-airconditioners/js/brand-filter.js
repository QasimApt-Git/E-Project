/* ============================================
   COSY AIRCONDITIONERS — brand-filter.js
   ============================================
   This file handles the brand filter buttons.
   When a user clicks a brand name (e.g., "Whirlpool"),
   only products of that brand should be shown.
   
   HOW IT WORKS (Student 2 will implement):
   1. Read products from data/products.json using fetch()
   2. Render product cards into #product-grid
   3. Add click event listeners to brand buttons
   4. On click, filter the displayed cards by brand
   5. "All" button resets and shows every card
   
   VANILLA JS ONLY — no jQuery or frameworks.
   ============================================ */

// Placeholder — Student 2 implements this.
console.log("brand-filter.js loaded — ready for Student 2");
