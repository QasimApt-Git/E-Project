/* ============================================
   COSY AIRCONDITIONERS — comparison.js
   ============================================
   This file handles the product comparison feature.
   
   HOW IT WORKS (Student 4 will implement):
   1. Add a checkbox to each product card
   2. Track which products are "selected for compare"
   3. Limit selection to maximum 3 products
   4. When user clicks "Compare", read specs from JSON
   5. Generate an HTML table showing specs side-by-side
   6. Display the table in the comparison section
   
   VANILLA JS ONLY — no jQuery or frameworks.
   ============================================ */

// Placeholder — Student 4 implements this.
console.log("comparison.js loaded — ready for Student 4");
