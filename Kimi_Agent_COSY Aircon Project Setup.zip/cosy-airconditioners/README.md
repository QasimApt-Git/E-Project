# COSY AIRCONDITIONERS
Student eProject | Aptech  
Tech: HTML, CSS, Bootstrap, minimal JS  
Team: 5 Members

## About the Project
COSY AIRCONDITIONERS is a student-built website for browsing and comparing air conditioners. It showcases products from four major brands: Whirlpool, LG, Samsung, and Daikin.

## Tech Stack
- **VS Code** – Code editor
- **HTML5** – Semantic markup
- **CSS3** – Custom styling with CSS variables
- **Bootstrap 5.3.2 (CDN)** – Responsive grid & components
- **Minimal JavaScript** – No frameworks, plain JS only
- **Git & GitHub** – Version control
- **Brave Browser** – Testing & debugging

## Folder Structure
```
/
├── index.html
├── css/
│   └── styles.css
├── js/
│   ├── brand-filter.js
│   ├── comparison.js
│   └── contact-form.js
├── pages/
│   └── contact.html
├── data/
│   └── products.json
├── docs/
│   └── (detailed specification .docx files)
├── images/
└── .gitignore
```

## Team Members (5 Students)
Each student owns a section of the website:
1. **Student 1 (Foundation Developer)** – Folder structure, JSON data, CSS variables, skeleton HTML, README
2. **Student 2** – Navbar, Hero section, Brand filter buttons
3. **Student 3** – Product catalog cards, Bootstrap modals for product details
4. **Student 4** – Comparison section (select products, compare specs side-by-side)
5. **Student 5** – Contact form validation, footer, contact page integration

## How to Run
1. Open the project folder in VS Code
2. Right-click `index.html` → **Open with Live Server** (or double-click to open in Brave)
3. Ensure you have an internet connection for Bootstrap CDN links to load

## License
This is an educational project created for Aptech eProject evaluation.
